export AWS_ACCESS_KEY_ID=AKIAIXXRI3324VSYSMJA
export AWS_SECRET_ACCESS_KEY=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


cloudera-director bootstrap-remote ./aws.simple.conf --lp.remote.username=admin --lp.remote.password=admin --lp.remote.hostAndPort=localhost:7189
