export AWS_ACCESS_KEY_ID=AKIAJRS7NUAMTXFLDOKA
export AWS_SECRET_ACCESS_KEY=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

cloudera-director bootstrap-remote ./aws.simple.conf --lp.remote.username=admin --lp.remote.password=admin --lp.remote.hostAndPort=localhost:7189
